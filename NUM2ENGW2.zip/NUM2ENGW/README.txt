1.import the project
2.Do a maven build
3.run EnglishNumbersToWords.java to run the application
4.run EnglishNumbersToWordsMocTester.java in to run the junit