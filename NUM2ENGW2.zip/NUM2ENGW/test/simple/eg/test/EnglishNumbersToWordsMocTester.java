package simple.eg.test;

 

import static org.mockito.Mockito.when;

 

import org.junit.Assert;

import org.junit.Test;

import org.junit.runner.RunWith;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.runners.MockitoJUnitRunner;

 

import simple.eg.impl.EnglishNumbersToWords;            

 

@RunWith(MockitoJUnitRunner.class)

public class EnglishNumbersToWordsMocTester {

             

              //@Mock annotation is used to create mock object of actual object

             

                 @Mock

                 EnglishNumbersToWords englishNumbersToWords = new EnglishNumbersToWords();

                

                 @Test

                 public void testConvert(){

                    //add the behavior of  service to convert a number

                    when(englishNumbersToWords.convert(56945781)).thenReturn("fifty six million nine hundred forty five thousand seven hundred eighty one");

                                          

                    //test the convert functionality

                    Assert.assertEquals(englishNumbersToWords.convert(56945781),"fifty six million nine hundred forty five thousand seven hundred eighty one");

                 }
                 
                 @Test
                 public void testconvertLessThanOneThousand(){

                     //add the behavior of  service to convertLessThanOneThousand number

                     when(englishNumbersToWords.convertLessThanOneThousand(118)).thenReturn("one hundred eighteen");

                                           

                     //test the convertLessThanOneThousand functionality

                     Assert.assertEquals(englishNumbersToWords.convertLessThanOneThousand(118),"one hundred eighteen");
                  }

 

}