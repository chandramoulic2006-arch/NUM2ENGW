package simple.eg.service;

 

public interface IEnglishNumbersToWords {

      

       public String convertLessThanOneThousand(int number);

       public String convert(long number);

 

}